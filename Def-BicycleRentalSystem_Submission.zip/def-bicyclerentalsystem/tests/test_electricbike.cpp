#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "../include/ElectricBike.hpp"

TEST_CASE("Electric Bike Initialization") {
    ElectricBike ebike;

    SECTION("Default Construction") {
        REQUIRE(ebike.getType() == "electric");
        REQUIRE(ebike.isBikeAvailable() == true);
        REQUIRE(ebike.getBatteryLife() == 5.0);
    }
}

TEST_CASE("Electric Bike Rental Logic") {
    ElectricBike ebike;

    SECTION("Successful Rental") {
        REQUIRE(ebike.rentBike(2.5) == true);
        REQUIRE(ebike.isBikeAvailable() == false);
        REQUIRE(ebike.getBatteryLife() == 2.5);
    }

    SECTION("Insufficient Battery") {
        REQUIRE(ebike.rentBike(5.1) == false); // Exceeds 5h battery
        REQUIRE(ebike.isBikeAvailable() == true); // Should remain available
        REQUIRE(ebike.getBatteryLife() == 5.0);  // Battery unchanged
    }

    SECTION("Back-to-Back Rentals") {
        REQUIRE(ebike.rentBike(3.0) == true);
        REQUIRE(ebike.rentBike(1.0) == false); // Already rented
        REQUIRE(ebike.getBatteryLife() == 2.0);
    }
}

TEST_CASE("Battery Edge Cases") {
    ElectricBike ebike;

    SECTION("Exact Battery Usage") {
        REQUIRE(ebike.rentBike(5.0) == true); // Uses full battery
        REQUIRE(ebike.getBatteryLife() == 0.0);
    }

    SECTION("Fractional Hour Rentals") {
        REQUIRE(ebike.rentBike(0.25) == true); // 15-minute rental
        REQUIRE(ebike.getBatteryLife() == 4.75);
    }
}

TEST_CASE("Recharge Functionality") {
    ElectricBike ebike;
    ebike.rentBike(4.0);

    SECTION("Recharge Resets State") {
        ebike.recharge();
        REQUIRE(ebike.getBatteryLife() == 5.0);
        REQUIRE(ebike.isBikeAvailable() == true);
        REQUIRE(ebike.rentBike(1.0) == true); // Verify available for new rentals
    }

    SECTION("Partial Usage Then Recharge") {
        REQUIRE(ebike.getBatteryLife() == 1.0);
        ebike.recharge();
        REQUIRE(ebike.rentBike(5.0) == true); // Full battery available
    }
}

TEST_CASE("Invalid Rental Durations") {
    ElectricBike ebike;

    SECTION("Negative Hours") {
        REQUIRE(ebike.rentBike(-1.0) == false);
        REQUIRE(ebike.isBikeAvailable() == true);
    }

    SECTION("Zero Hours") {
        REQUIRE(ebike.rentBike(0.0) == false);
    }

    SECTION("Exceeds 24 Hours") {
        REQUIRE(ebike.rentBike(24.1) == false);
    }
}