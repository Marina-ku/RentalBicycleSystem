#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include  "RentalSystem.hpp"


TEST_CASE("Rental System Inventory Management") {
    RentalSystem system;
    
    SECTION("Initial Bike Counts") {
        REQUIRE(system.getAvailableBikes("electric") == 10);
        REQUIRE(system.getAvailableBikes("push") == 30);
    }

    SECTION("Successful Rentals Affect Inventory") {
        system.processRental("electric", 9.0, 11.0);
        REQUIRE(system.getAvailableBikes("electric") == 9);
    }
}