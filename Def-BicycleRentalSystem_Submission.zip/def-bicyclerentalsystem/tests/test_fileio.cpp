#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "FileHandler.hpp"


TEST_CASE("Input File Processing") {
    FileHandler handler;
    
    SECTION("Valid File Parsing") {
        REQUIRE(handler.loadRequests("tests/test_input.txt") == true);
        REQUIRE(handler.getRequestCount() == 3);
    }

    SECTION("Invalid File Handling") {
        REQUIRE(handler.loadRequests("nonexistent.txt") == false);
    }
}