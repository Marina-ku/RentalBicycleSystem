#define CATCH_CONFIG_MAIN
#include "catch.hpp"
//#include "../src/ReportGenerator.h"
#include "../include/ReportGenerator.h"




TEST_CASE("Daily Report Generation") {
    ReportGenerator reporter;
    
    SECTION("Correct File Naming") {
        REQUIRE(reporter.generateReport("15092025") == "15092025.dat");
    }

    SECTION("Report Content Format") {
        auto content = reporter.getReportContent();
        REQUIRE(content.find("Total Takings: £") != std::string::npos);
    }
}