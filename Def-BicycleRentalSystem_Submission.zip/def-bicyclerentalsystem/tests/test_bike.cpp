#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "../include/Bike.hpp"

// Mock derived class for testing pure virtual functions
class TestBike : public Bike {
public:
    TestBike(double rate, const std::string& type = "test") 
        : Bike(rate, type) {}

    bool rentBike(double hours) override {
        if (!isAvailable || hours <= 0) return false;
        isAvailable = false;
        return true;
    }
};

TEST_CASE("Bike Constructor Initialization") {
    SECTION("Default Type Assignment") {
        TestBike bike(1.5);
        REQUIRE(bike.getType() == "test");
        REQUIRE(bike.isBikeAvailable() == true);
        REQUIRE(bike.calculateCost(2.0) == 3.0);
    }

    SECTION("Custom Type Assignment") {
        TestBike bike(2.0, "custom");
        REQUIRE(bike.getType() == "custom");
    }
}

TEST_CASE("Bike Rental Mechanics") {
    TestBike bike(1.0);

    SECTION("Successful Rental") {
        REQUIRE(bike.rentBike(1.5) == true);
        REQUIRE(bike.isBikeAvailable() == false);
    }

    SECTION("Invalid Rental Attempts") {
        REQUIRE(bike.rentBike(-1.0) == false);
        REQUIRE(bike.rentBike(0.0) == false);
        bike.rentBike(1.0);
        REQUIRE(bike.rentBike(1.0) == false);
    }
}

TEST_CASE("Bike Return Functionality") {
    TestBike bike(2.0);
    bike.rentBike(1.0);

    SECTION("Standard Return") {
        bike.returnBike();
        REQUIRE(bike.isBikeAvailable() == true);
        REQUIRE(bike.rentBike(1.0) == true);
    }
}

TEST_CASE("Cost Calculation") {
    TestBike cheapBike(1.0), expensiveBike(5.0);

    SECTION("Normal Rates") {
        REQUIRE(cheapBike.calculateCost(3.0) == 3.0);
        REQUIRE(expensiveBike.calculateCost(2.0) == 10.0);
    }

    SECTION("Edge Cases") {
        REQUIRE(cheapBike.calculateCost(0.0) == 0.0);
        REQUIRE(expensiveBike.calculateCost(24.0) == 120.0);
    }
}

TEST_CASE("Bike Polymorphism") {
    Bike* bike = new TestBike(3.0, "polymorphic_test");
    
    SECTION("Virtual Function Calls") {
        REQUIRE(bike->getType() == "polymorphic_test");
        REQUIRE(bike->rentBike(1.0) == true);
        REQUIRE(bike->isBikeAvailable() == false);
        REQUIRE(bike->calculateCost(2.0) == 6.0);
    }
    
    delete bike;
}