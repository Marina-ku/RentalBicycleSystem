#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "../include/PushBike.hpp"

TEST_CASE("PushBike Initialization") {
    PushBike bike;

    SECTION("Default Construction") {
        REQUIRE(bike.getType() == "push");
        REQUIRE(bike.isBikeAvailable() == true);
        REQUIRE(bike.calculateCost(2.0) == 2.0); // £1/hour rate
    }
}

TEST_CASE("PushBike Rental Logic") {
    PushBike bike;

    SECTION("Successful Rental") {
        REQUIRE(bike.rentBike(3.5) == true);
        REQUIRE(bike.isBikeAvailable() == false);
    }

    SECTION("Double Rental Attempt") {
        bike.rentBike(1.0);
        REQUIRE(bike.rentBike(1.0) == false); // Already rented
    }

    SECTION("Return Bike Availability") {
        bike.rentBike(2.0);
        bike.returnBike();
        REQUIRE(bike.isBikeAvailable() == true);
    }
}

TEST_CASE("PushBike Input Validation") {
    PushBike bike;

    SECTION("Negative Hours") {
        REQUIRE(bike.rentBike(-1.5) == false);
        REQUIRE(bike.isBikeAvailable() == true); // State unchanged
    }

    SECTION("Zero Hours") {
        REQUIRE(bike.rentBike(0.0) == false);
    }

    SECTION("Fractional Hours") {
        REQUIRE(bike.rentBike(0.25) == true); // 15-minute rental
        REQUIRE(bike.calculateCost(0.25) == 0.25); // £0.25 charge
    }
}

TEST_CASE("PushBike Cost Calculation") {
    PushBike bike;

    SECTION("Standard Rental") {
        REQUIRE(bike.calculateCost(4.0) == 4.0); // 4h × £1
    }

    SECTION("24-Hour Maximum") {
        REQUIRE(bike.rentBike(24.0) == true); // Max allowed duration
        REQUIRE(bike.calculateCost(24.0) == 24.0);
    }

    SECTION("Beyond 24 Hours") {
        REQUIRE(bike.rentBike(24.1) == false); // Exceeds max duration
    }
}