/**
 * @file ElectricBike.hpp
 * @brief header for electric bike class with battery management
 * @author [Mary Adekanmbi]
 * @date [27/05/2025]
 */

#ifndef ELECTRIC_BIKE_HPP
#define ELECTRIC_BIKE_HPP

#include "Bike.hpp"

class ElectricBike : public Bike {
private:
    double batteryLife; ///< Remaining battery in hours

public:
    /**
     * @brief Constructor initialises electric bike with £3/hour rate and 5-hour battery
     */
    ElectricBike();

    /**
     * @brief Attempt to rent the bike
     * @param hours Duration of rental in hours
     * @return true if rental succeeded, false if bike unavailable or insufficient battery
     */
    bool rentBike(double hours) override;

    /**
     * @brief Fully recharge the battery (5 hours) and make bike available
     */
    void recharge();

    /**
     * @brief Get remaining battery life
     * @return Current battery life in hours
     */
    double getBatteryLife() const;
};

#endif // ELECTRIC_BIKE_HPP