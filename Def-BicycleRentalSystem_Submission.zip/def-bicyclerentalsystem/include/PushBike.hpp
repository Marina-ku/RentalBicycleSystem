/**
 * @file PushBike.hpp
 * @brief Regular bicycle (no motor)
 */
#pragma once
#include "Bike.hpp"

/**
 * @class PushBike
 * @brief A normal pedal bike
 *
 * This is the classic bicycle that you pedal yourself.
 * It inherits all basic bike features from the Bike class.
 */
class PushBike : public Bike {
public:
    /**
     * @brief Creates a new push bike
     * 
     * Sets up a bike that:
     * - Costs 1.0 per hour to rent
     * - Is marked as a "push" bike type
     */
    PushBike();

    /**
     * @brief Rent this bike
     * @param hours How many hours to rent for (must be more than 0)
     * @return true if rented successfully, false if failed
     *
     * Checks:
     * 1. Is the bike available?
     * 2. Is the rental time valid?
     *
     * If both checks pass, the bike gets marked as rented.
     */
    bool rentBike(double hours) override;
};