#ifndef FILEHANDLER_HPP
#define FILEHANDLER_HPP

#include <string>
#include <vector>

class FileHandler {
public:
    bool loadRequests(const std::string& filename);
    int getRequestCount() const;

private:
    std::vector<std::string> requests;  // stores loaded requests (adjust type if needed)
};

#endif // FILEHANDLER_HPP
