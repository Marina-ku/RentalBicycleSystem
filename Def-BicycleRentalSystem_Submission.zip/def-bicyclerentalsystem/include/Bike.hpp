/**
 * @file Bike.hpp
 * @brief Base class for rental bicycles
 */
#ifndef BIKE_H_
#define BIKE_H_

#include <string>

/// Base class for push and electric bikes
class Bike {
protected:
    bool isAvailable;    ///< Current rental status
    double hourlyRate;   ///< Rental rate (£/hour)
    std::string type;    ///< Bike type ("push"/"electric")

public:
    /// @param rate Hourly rate in pounds
    /// @param bikeType Bike type (default: "push")
    Bike(double rate, const std::string& bikeType = "push");
    
    virtual ~Bike() = default;
    
    /// Attempt to rent bike for given hours
    virtual bool rentBike(double hours) = 0;
    
    /// Calculate cost: hours * hourlyRate
    virtual double calculateCost(double hours) const {
        return hours * hourlyRate;
    }
    
    /// Check availability
    bool isBikeAvailable() const { return isAvailable; }
    
    /// Mark bike as returned
    virtual void returnBike() { isAvailable = true; }
    
    /// Get bike type
    std::string getType() const { return type; }
};

#endif // BIKE_H_