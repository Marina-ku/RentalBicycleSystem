#ifndef RENTALSYSTEM_HPP
#define RENTALSYSTEM_HPP

#include <string>
#include <unordered_map>

/**
 * @class RentalSystem
 * @brief Manages the inventory and rental process for different types of bikes.
 */
class RentalSystem {
private:
    std::unordered_map<std::string, int> availableBikes;

public:
    RentalSystem();

    int getAvailableBikes(const std::string& type) const;

    void processRental(const std::string& type, double startTime, double endTime);
};

#endif // RENTALSYSTEM_HPP
