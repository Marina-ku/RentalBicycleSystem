var searchData=
[
  ['type_0',['type',['../classBike.html#a7157ed0f72ae2017692356b706a98dda',1,'Bike']]]
];
