var searchData=
[
  ['getbatterylife_0',['getBatteryLife',['../classElectricBike.html#a2b1b423e77e8383178885be7cd48325c',1,'ElectricBike']]],
  ['gettype_1',['getType',['../classBike.html#a0f31c4d0bdce13d334c3f3ef959fbee6',1,'Bike']]]
];
