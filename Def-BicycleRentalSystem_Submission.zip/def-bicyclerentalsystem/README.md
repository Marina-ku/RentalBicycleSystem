# Bicycle Rental System

## Overview
This project implements a Bicycle Rental System featuring two types of bikes: Push Bikes and Electric Bikes. The system manages rentals, tracks bike availability, and generates daily rental reports including revenue and missed rental statistics.

## Features
- Rent push bikes and electric bikes with duration tracking.
- Manage bike availability and battery life (for electric bikes).
- Generate daily reports with rental statistics and bike statuses.
- Handles invalid rental requests gracefully.

## Technologies
- C++17
- Catch2 testing framework for unit tests
- Makefile for build automation

## Project Structure
- `src/`: Source code files.
- `include/`: Header files.
- `tests/`: Unit test files using Catch2.
- `Makefile`: Build and test automation.

## Building and Running
To build the project and run the main program:

```bash
make clean && make all
./bike_rental
