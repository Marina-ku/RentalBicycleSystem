#include <iostream>
#include <fstream>
#include <vector>
#include <iomanip>
#include <sstream>
#include "../include/Bike.hpp"
#include "../include/PushBike.hpp"
#include "../include/ElectricBike.hpp"

const int TOTAL_PUSH_BIKES = 30;
const int TOTAL_ELECTRIC_BIKES = 10;

// Global trackers
int pushBikesRented = 0;
int electricBikesRented = 0;
int missedPushRentals = 0;
int missedElectricRentals = 0;
double totalRevenue = 0.0;
std::string currentDate;

std::vector<PushBike> pushBikes(TOTAL_PUSH_BIKES);
std::vector<ElectricBike> electricBikes(TOTAL_ELECTRIC_BIKES);

double timeToHours(const std::string& time) {
    size_t dotPos = time.find('.');
    int hours = std::stoi(time.substr(0, dotPos));
    int minutes = std::stoi(time.substr(dotPos + 1));
    return hours + (minutes / 60.0);
}

void processRental(const std::string& type, double startTime, double endTime) {
    double duration = endTime - startTime;
    
    // Validate duration
    if (duration <= 0) {
        (type == "push bike") ? missedPushRentals++ : missedElectricRentals++;
        return;
    }

    bool rented = false;
    if (type == "push bike") {
        for (auto& bike : pushBikes) {
            if (bike.rentBike(duration)) {  // Removed redundant isAvailable check
                pushBikesRented++;
                totalRevenue += 1.0 * duration; // £1/hour
                rented = true;
                break;
            }
        }
        if (!rented) missedPushRentals++;
    } 
    else if (type == "electric bike") {
        for (auto& bike : electricBikes) {
            if (bike.rentBike(duration)) {
                electricBikesRented++;
                totalRevenue += 3.0 * duration; // £3/hour
                rented = true;
                break;
            }
        }
        if (!rented) missedElectricRentals++;
    }
}

void generateDailyReport() {
    if (currentDate.empty()) return;

    // Build filename from date (e.g., "27052024.dat")
    std::string filename;
    for (char c : currentDate) {
        if (c != '/') filename += c;
    }
    filename += ".dat";

    std::ofstream outFile(filename);
    if (!outFile) {
        std::cerr << "Error creating report file: " << filename << "\n";
        return;
    }

    // Helper lambda to write to both outFile and std::cout
    auto writeLine = [&](const std::string& line) {
        outFile << line << "\n";
        std::cout << line << "\n";
    };

    // Report contents
    std::ostringstream oss;
    oss << "Total takings: £" << std::fixed << std::setprecision(2) << totalRevenue;
    writeLine(oss.str());

    writeLine("PushBike rentals: " + std::to_string(pushBikesRented));
    writeLine("ElectricBike rentals: " + std::to_string(electricBikesRented));
    writeLine("Missed PushBike rentals: " + std::to_string(missedPushRentals));
    writeLine("Missed ElectricBike rentals: " + std::to_string(missedElectricRentals));
    writeLine("");  // Blank line

    writeLine("ElectricBike battery status:");
    for (size_t i = 0; i < electricBikes.size(); ++i) {
        std::ostringstream status;
        status << "Bike " << (i + 1) << ": "
               << std::fixed << std::setprecision(1)
               << electricBikes[i].getBatteryLife() << "h remaining";
        writeLine(status.str());
    }

    // Recharge all electric bikes for the next day
    for (auto& bike : electricBikes) {
        bike.recharge();
    }

    // Reset daily stats
    pushBikesRented = 0;
    electricBikesRented = 0;
    missedPushRentals = 0;
    missedElectricRentals = 0;
    totalRevenue = 0.0;
}

int main() {
    std::cout << "Starting Bicycle Rental System...\n";

    // Set current date (example)
    currentDate = "27/05/2025";

    // Simulate some rentals
    processRental("push bike", timeToHours("9.00"), timeToHours("10.30"));
    processRental("electric bike", timeToHours("10.00"), timeToHours("12.00"));
    processRental("push bike", timeToHours("11.00"), timeToHours("11.15"));

    // Generate daily report
    generateDailyReport();

    return 0;
}
