/**
 * @file Bike.cpp
 * @brief Implementation of the Bike class constructor
 * @author Mary Adekanmbi 
 * @date Created: 2024-05-27
 */

#include "../include/Bike.hpp"

/**
 * @brief Constructor initialising bike rate, type, and availability
 * @param rate Hourly rental rate in pounds
 * @param bikeType Type of bike ("push"/"electric")
 */
Bike::Bike(double rate, const std::string& bikeType) 
    : isAvailable(true), hourlyRate(rate), type(bikeType) {}