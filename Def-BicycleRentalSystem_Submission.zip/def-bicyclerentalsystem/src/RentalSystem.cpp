#include "RentalSystem.hpp"

RentalSystem::RentalSystem() {
    availableBikes["electric"] = 10;
    availableBikes["push"] = 30;
}

int RentalSystem::getAvailableBikes(const std::string& type) const {
    auto it = availableBikes.find(type);
    if (it != availableBikes.end()) {
        return it->second;
    }
    return 0;
}

void RentalSystem::processRental(const std::string& type, double startTime, double endTime) {
    if (availableBikes[type] > 0) {
        availableBikes[type]--;
        // You can add additional rental logic here.
    }
}
