/**
 * @file ElectricBike.cpp
 * @brief Electric bike implementation with battery tracking
 * @author [Mary Adekanmbi]
 * @date [27/05/25]
 */
#include "../include/ElectricBike.hpp"

ElectricBike::ElectricBike() : Bike(3.0, "electric"), batteryLife(5.0) {} // £3/hour, 5-hour battery

bool ElectricBike::rentBike(double hours) {
    if (!isAvailable) return false;  // Bike already rented
    
    if (hours <= 0 || hours > 24) {  // Validate rental duration (NEW)
        return false;
    }

    if (batteryLife < hours) {       // battery insufficent
        return false;
    }

    batteryLife -= hours;
    isAvailable = false;
    return true;
}

void ElectricBike::recharge() {
    batteryLife = 5.0;               // Reset to full charge
    isAvailable = true;              // Make bike available again (NEW)
}

double ElectricBike::getBatteryLife() const {  // NEW: For testing/reporting
    return batteryLife;
}