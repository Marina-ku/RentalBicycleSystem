/** 
 * @file PushBike.cpp
 * @brief Push bike implementation
 */
#include "../include/PushBike.hpp"

// Constructor: fl/hour-rate, type="push"
PushBike::PushBike() : Bike(1.0, "push") {}

// Rental Logic
bool PushBike::rentBike(double hours) {
    if (!isAvailable || hours <= 0) {
        return false; // Reject if unavailable or invalid duration
    }
    isAvailable = false;
    return true;
}