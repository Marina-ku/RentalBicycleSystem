#include "FileHandler.hpp"
#include <fstream>
#include <iostream>

bool FileHandler::loadRequests(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Failed to open file: " << filename << "\n";
        return false;
    }

    requests.clear(); // clear any previous data

    std::string line;
    while (std::getline(file, line)) {
        requests.push_back(line);
    }
    return true;
}

int FileHandler::getRequestCount() const {
    return static_cast<int>(requests.size());
}
